#include "mbed.h"
#include "xbee_command.h"

DigitalOut led1(LED1);
DigitalOut led2(LED2);
DigitalOut led4(LED4);
Serial serialXBEE(p13, p14);
Serial          pc(USBTX, USBRX);  
DigitalOut      resetXBEE(p8);
uint8_t  at_cmd_frame[255];
uint8_t  message_recu[255];
uint8_t  remote_command_request_frame[255];


//uint16_t* config_values[]  = {&PAN_ID, &FREQ_LECTURE_CAPTEURS}; // Tableau de pointeur pour variables de configurations



/**
    Isole les 4 bits les plus significatif dune valeur short et la renvoie 
    en char
*/
uint8_t get_MSB(uint16_t info){
    uint8_t MSB = (info >> 8) & 0x00FF;    
    
    return MSB;
}
/**
    Isole les 4 bits les moins significatif dune valeur short et la renvoie 
    en char
*/
uint8_t get_LSB(uint16_t info){
    uint8_t LSB =  info & 0x00FF;
    
    return LSB;
}

/**
    Construit la trame pour envoie de commande AT 
*/
uint8_t build_AT_cmd_frame(uint8_t frame_id, uint16_t p_AT_cmd, uint8_t* p_value, uint8_t p_value_length, uint8_t* p_at_cmd_frame){  
    uint8_t at_cmd_char1 = get_MSB(p_AT_cmd);
    uint8_t at_cmd_char2 = get_LSB(p_AT_cmd);
    uint8_t checksum     = 0; 
    uint8_t frame_index  = 0;
    
    uint16_t length = p_value_length + 0x04;
    uint8_t  MSB    = get_MSB(length);
    uint8_t  LSB    = get_LSB(length);
    //                                                                                       (optional)
    //                {ST,    MSB,    LSB,    0x08,    frameID,   AT_cmd_1,     AT_cmd_2,     p_value,  checksum}
    
    p_at_cmd_frame[0] = START;
    p_at_cmd_frame[1] = MSB;
    p_at_cmd_frame[2] = LSB;
    p_at_cmd_frame[3] = AT_CMD;
    p_at_cmd_frame[4] = frame_id;
    p_at_cmd_frame[5] = at_cmd_char1;
    p_at_cmd_frame[6] = at_cmd_char2;
    
    if(p_value_length != 0){
        for(frame_index = 7; frame_index < p_value_length + 7; frame_index++){
            p_at_cmd_frame[frame_index] = p_value[frame_index - 7];
        }
    }
    
    // Calculate checksum
    for(frame_index = 3; frame_index < 7 + p_value_length; frame_index++){
        checksum += p_at_cmd_frame[frame_index]; 
        //pc.printf(" checksum = %02X \r\n", checksum);   
    }

    checksum = 0xFF - checksum;
    
    p_at_cmd_frame[frame_index] = checksum; // checksum
    
    return frame_index + 1;
}


void initialise_xbee(uint16_t pan_id){
    uint8_t MSB_pan_id = get_MSB(pan_id);
    uint8_t LSB_pan_id = get_LSB(pan_id);
    
    uint8_t enter_at_cmd_mode[] = {'+', '+', '+'};
    uint8_t data_pan_id[]   = {MSB_pan_id, LSB_pan_id};
    
    uint8_t frame_length = 0;
    
    // Mettre a 0 la broche RESET pour 400ms
    resetXBEE = 0;
    wait_ms(400);
    resetXBEE = 1;     
    
    // +++
    send_frame_2xbee(enter_at_cmd_mode, sizeof(enter_at_cmd_mode)); 
    wait_ms(400);
    
    receive_Xbee(message_recu);
     // ID = 9600
    frame_length = build_AT_cmd_frame(FRAME_ID01, AT_CMD_ID, data_pan_id, sizeof(data_pan_id), at_cmd_frame);
    send_frame_2xbee(at_cmd_frame, frame_length);
    wait_ms(30);

    receive_Xbee(message_recu);
    // WR
    frame_length = build_AT_cmd_frame(FRAME_ID01, AT_CMD_WR, NULL, 0, at_cmd_frame);
    send_frame_2xbee(at_cmd_frame, frame_length);
    wait_ms(30);

    receive_Xbee(message_recu);
    
    // AC
    frame_length = build_AT_cmd_frame(FRAME_ID01, AT_CMD_AC, NULL, 0, at_cmd_frame);
    send_frame_2xbee(at_cmd_frame, frame_length);
    wait_ms(30);
    
    receive_Xbee(message_recu);    
    
    //return true;
    }

/**
    Mise dans un tableau de la trame recue par le xbee
*/
uint8_t receive_Xbee(uint8_t* message_recu){
    uint8_t caratere_recu;
    uint8_t message_length = 0;
    
    while(serialXBEE.readable() == 0){
        //pc.printf(" ");
    }

    while(serialXBEE.readable() == 1){
        //pc.printf("%d %d \r\n", serialXBEE.readable(), pc.readable());
        led1 = !led1;  
        caratere_recu = serialXBEE.getc();  pc.printf("%02X ", caratere_recu);// ST 
        message_recu[message_length] = caratere_recu;
        message_length++;
        wait_ms(50);
    }
    
    pc.printf("\r\n"); 
    return message_length;
}

bool send_frame_2xbee(uint8_t* frame, uint8_t frame_length){
    for(uint8_t i = 0; i < frame_length; i++){
        led2 = !led2;
        serialXBEE.putc(frame[i]); 
        pc.printf("%02X ", frame[i]);
        wait_ms(50);
    }
    pc.printf("%\r\n"); 
    return true;
 
}
/**
    Construit la trame pour envoie de commande AT a un xbee distant
*/
uint8_t build_remote_cmd_request_frame(uint8_t p_frame_id,  uint16_t p_pan_id, uint16_t p_AT_cmd, uint8_t* p_remote_cmd_request_frame){  
    uint64_t mask_mac_id = 0x00000000000000FF;
    
    
    p_pan_id = 0xFFFE;
    uint8_t  mac_bit_shift = 56;
    uint8_t  frame_index   = 0;
    uint16_t checksum      = 0x0000;
    
    uint16_t length = 15;
    uint8_t MSB = get_MSB(length);
    uint8_t LSB = get_LSB(length);

    uint8_t at_cmd_char1 = get_MSB(p_AT_cmd);
    uint8_t at_cmd_char2 = get_LSB(p_AT_cmd);
    
    uint64_t mac_address = 0x00000000;     // broadcast
    
    p_remote_cmd_request_frame[0] = START;         // ST
    p_remote_cmd_request_frame[1] = MSB;           // MSB
    p_remote_cmd_request_frame[2] = LSB;           // LSB
    p_remote_cmd_request_frame[3] = RMT_AT_RQST;    // frame type 0x10
    p_remote_cmd_request_frame[4] = p_frame_id;    // frame id
    // 64b destination address 5 a 12
    for(frame_index = 5; frame_index < 5 + 8; frame_index++){       
        p_remote_cmd_request_frame[frame_index]  = (mac_address >> mac_bit_shift) & mask_mac_id;
        mac_bit_shift = mac_bit_shift - 8;
    }
    // 16b destination network address 13 et 14
    p_remote_cmd_request_frame[13] = (p_pan_id >> 8) & 0x00FF;    // MSB pan_id 
    p_remote_cmd_request_frame[14] = p_pan_id & 0x00FF;   // LSB_pan_id 
    
    p_remote_cmd_request_frame[15] = 0x02;  // Remote Command Option
    
    p_remote_cmd_request_frame[16] = at_cmd_char1;  // AT Command char1
    p_remote_cmd_request_frame[17] = at_cmd_char2;  // At Command char2
    
    // Calculate checksum
    for(frame_index = 3; frame_index < 18; frame_index++){
        checksum += p_remote_cmd_request_frame[frame_index]; 
        //pc.printf(" checksum = %02X \r\n", checksum);   
    }
    
    checksum = 0xFF - checksum;
    
    p_remote_cmd_request_frame[frame_index] = checksum; // checksum
    
    return frame_index + 1;
}
/**
    Construit la trame pour envoie de de trame vers un xbee distant
*/
uint8_t build_tx_request_frame(uint8_t* p_mac_address, uint16_t p_pan_id, uint8_t* p_tx_request_frame, uint8_t *data, uint8_t data_length){ //{ST, MSB, LSB, 0x08, frameID, AT_cmd_1, AT_cmd_2, parameter_value (optional), checksum}   
    uint64_t mask_mac_id = 0x00000000000000FF;
    
    uint8_t  mac_bit_shift = 56;
    uint8_t  frame_index   = 0;
    uint16_t checksum      = 0x0000;
    
    uint16_t length = data_length + 14;
    uint8_t MSB = get_MSB(length);
    uint8_t LSB = get_LSB(length);
    
    p_tx_request_frame[0] = START;         // ST
    p_tx_request_frame[1] = MSB;           // MSB
    p_tx_request_frame[2] = LSB;           // LSB
    p_tx_request_frame[3] = TX_REQUEST;    // frame type 0x10
    p_tx_request_frame[4] = FRAME_ID01;    // frame id

    for(frame_index = 5; frame_index < 5 + 8; frame_index++){       
        p_tx_request_frame[frame_index]  = p_mac_address[frame_index - 5];
    }    

    p_tx_request_frame[13] = (p_pan_id >> 8) & 0x00FF;    // MSB pan_id 
    p_tx_request_frame[14] = p_pan_id & 0x00FF;   // LSB_pan_id 
    
    p_tx_request_frame[15] = 0x00;  // broadcast radius
    p_tx_request_frame[16] = 0x00;  // option
    
    // RF data
    for(frame_index = 17; frame_index < 17 + data_length; frame_index++){       
        p_tx_request_frame[frame_index]  = data[frame_index - 17];
    } 
    // Calculate checksum
    for(frame_index = 3; frame_index < 17 + data_length; frame_index++){
        checksum += p_tx_request_frame[frame_index]; 
        //pc.printf(" checksum = %02X \r\n", checksum);   
    }
    
    checksum = 0xFF - checksum;
    
    p_tx_request_frame[frame_index] = checksum; // checksum
    
    return frame_index + 1;
}

int main() {
    pc.printf(" reading live \r\n");// 
    //readConfigFile(*config_values);
    //read config file
    //init comunication and reset da shit 
    initialise_xbee(PAN_ID);
    
    uint8_t frame_length = build_remote_cmd_request_frame(FRAME_ID01, PAN_ID, AT_CMD_ID, remote_command_request_frame);
    send_frame_2xbee(remote_command_request_frame, frame_length);
    wait_ms(400);
    
    pc.printf(" Rooter up and running \r\n");// 
    led4 = 1;
    led2 =0;
    //send_frame_2xbee(test_message, sizeof(test_message)); 
    //pc.printf(" premier message envoyer\r\n");// 
    wait_ms(400);
    
}
